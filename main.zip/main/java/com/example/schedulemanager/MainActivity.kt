package com.example.schedulemanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.schedulemanager.data.AppDatabase
import com.example.schedulemanager.ui.screens.AssigneesTabContent
import com.example.schedulemanager.ui.screens.ScheduleScreen
import com.example.schedulemanager.ui.screens.TemplatesTabContent
import com.example.schedulemanager.ui.screens.ToolsScreen
import com.example.schedulemanager.ui.theme.ScheduleManagerTheme
import com.example.schedulemanager.viewmodel.ScheduleViewModel
import com.example.schedulemanager.viewmodel.ScheduleViewModelFactory

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Database and SharedPreferences
        val database = AppDatabase.getDatabase(applicationContext)
        val sharedPreferences = getSharedPreferences("schedule_prefs", MODE_PRIVATE)

        // Instantiate ViewModel with Room DAOs
        val viewModel: ScheduleViewModel by viewModels {
            ScheduleViewModelFactory(
                scheduleItemDao = database.scheduleItemDao(),
                assigneeDao = database.assigneeDao(),
                toolDao = database.toolDao(),
                sharedPreferences = sharedPreferences
            )
        }

        setContent {
            ScheduleManagerTheme {
                val selectedTabIndex by viewModel.selectedTabIndex.collectAsState()

                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            // Tab 0: Schedule
                            NavigationBarItem(
                                selected = selectedTabIndex == 0,
                                onClick = { viewModel.onTabSelected(0) },
                                icon = { Icon(imageVector = Icons.Default.DateRange, contentDescription = "Schedule") },
                                label = { Text("Schedule") }
                            )

                            // Tab 1: Assignees
                            NavigationBarItem(
                                selected = selectedTabIndex == 1,
                                onClick = { viewModel.onTabSelected(1) },
                                icon = { Icon(imageVector = Icons.Default.Person, contentDescription = "Assignees") },
                                label = { Text("Assignees") }
                            )

                            // Tab 2: Tools
                            NavigationBarItem(
                                selected = selectedTabIndex == 2,
                                onClick = { viewModel.onTabSelected(2) },
                                icon = { Icon(imageVector = Icons.Default.Build, contentDescription = "Tools") },
                                label = { Text("Tools") }
                            )

                            // Tab 3: Templates
                            NavigationBarItem(
                                selected = selectedTabIndex == 3,
                                onClick = { viewModel.onTabSelected(3) },
                                icon = { Icon(imageVector = Icons.Default.List, contentDescription = "Templates") },
                                label = { Text("Templates") }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (selectedTabIndex) {
                            0 -> ScheduleScreen(viewModel = viewModel)
                            1 -> AssigneesTabContent(viewModel = viewModel)
                            2 -> ToolsScreen(viewModel = viewModel)
                            3 -> TemplatesTabContent(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}