package com.example.schedulemanager

import android.app.Application
import com.example.schedulemanager.data.AppDatabase

class ScheduleApplication : Application() {

    // Lazy initialization ensures the database is created only when first accessed
    val database: AppDatabase by lazy {
        AppDatabase.getDatabase(this)
    }
}