package com.example.schedulemanager.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AssigneeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssignee(assignee: Assignee): Long

    @Query("SELECT * FROM assignees ORDER BY name ASC")
    fun getAllAssignees(): Flow<List<Assignee>>

    @Query("SELECT * FROM assignees WHERE LOWER(name) = LOWER(:name) LIMIT 1")
    suspend fun getAssigneeByName(name: String): Assignee?

    @Delete
    suspend fun deleteAssignee(assignee: Assignee): Int

    @Update
    suspend fun updateAssignee(assignee: Assignee)
}