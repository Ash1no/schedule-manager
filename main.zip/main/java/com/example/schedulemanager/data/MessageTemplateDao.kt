package com.example.schedulemanager.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageTemplateDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateTemplate(template: MessageTemplate): Long

    @Query("SELECT * FROM message_templates LIMIT 1")
    fun getTemplate(): Flow<MessageTemplate?>
}