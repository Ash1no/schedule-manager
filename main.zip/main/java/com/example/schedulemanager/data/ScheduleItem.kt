package com.example.schedulemanager.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "schedule_items",
    foreignKeys = [
        ForeignKey(
            entity = Assignee::class,
            parentColumns = ["id"],
            childColumns = ["assignee_id"],
            onDelete = ForeignKey.SET_NULL
        ),
        ForeignKey(
            entity = Tool::class,
            parentColumns = ["id"],
            childColumns = ["tool_id"],
            onDelete = ForeignKey.SET_NULL
        )
    ]
)
data class ScheduleItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "date")
    val date: String, // Format: YYYY-MM-DD

    @ColumnInfo(name = "address")
    val address: String,

    @ColumnInfo(name = "assignee_id")
    val assigneeId: Long? = null,

    @ColumnInfo(name = "tool_id")
    val toolId: Long? = null
)