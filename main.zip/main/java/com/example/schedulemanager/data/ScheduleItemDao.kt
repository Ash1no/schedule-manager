package com.example.schedulemanager.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduleItemDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScheduleItem(item: ScheduleItem): Long

    @Update
    suspend fun updateScheduleItem(item: ScheduleItem): Int

    @Query("SELECT * FROM schedule_items WHERE date = :date ORDER BY id ASC")
    fun getScheduleForDate(date: String): Flow<List<ScheduleItem>>

    // --- ADDED: Fetch all schedule items for week strip event dots ---
    @Query("SELECT * FROM schedule_items ORDER BY id ASC")
    fun getAllScheduleItems(): Flow<List<ScheduleItem>>

    @Delete
    suspend fun deleteScheduleItem(item: ScheduleItem): Int
}