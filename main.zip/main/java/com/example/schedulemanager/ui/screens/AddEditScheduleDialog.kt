package com.example.schedulemanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.PopupProperties
import com.example.schedulemanager.data.Assignee
import com.example.schedulemanager.data.ScheduleItem
import com.example.schedulemanager.data.Tool

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditScheduleDialog(
    selectedDate: String,
    existingItem: ScheduleItem? = null,
    assignees: List<Assignee>,
    tools: List<Tool>,
    onDismiss: () -> Unit,
    onSave: (ScheduleItem) -> Unit
) {
    // 1. Address state
    var address by remember { mutableStateOf(existingItem?.address ?: "") }

    // 2. Assignee Dropdown & Autocomplete state
    var assigneeExpanded by remember { mutableStateOf(false) }
    var selectedAssignee by remember { mutableStateOf(assignees.find { it.id == existingItem?.assigneeId }) }
    var assigneeSearchText by remember { mutableStateOf(selectedAssignee?.name ?: "") }

    val filteredAssignees = remember(assigneeSearchText, assignees) {
        assignees.filter {
            it.name.startsWith(assigneeSearchText, ignoreCase = true)
        }
    }

    val showUnassignedOption = remember(assigneeSearchText) {
        "Unassigned".startsWith(assigneeSearchText, ignoreCase = true) || assigneeSearchText.isEmpty()
    }

    // 3. Tool Dropdown & Autocomplete state (identical behavior to Assignee)
    var toolExpanded by remember { mutableStateOf(false) }
    var selectedTool by remember { mutableStateOf(tools.find { it.id == existingItem?.toolId }) }
    var toolSearchText by remember { mutableStateOf(selectedTool?.name ?: "") }

    val filteredTools = remember(toolSearchText, tools) {
        tools.filter {
            it.name.startsWith(toolSearchText, ignoreCase = true)
        }
    }

    val showNoToolOption = remember(toolSearchText) {
        "None".startsWith(toolSearchText, ignoreCase = true) || toolSearchText.isEmpty()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existingItem == null) "Add Schedule" else "Edit Schedule") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // --- ADDRESS FIELD ---
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address / Location") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // --- ASSIGNEE AUTOCOMPLETE ---
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = assigneeSearchText,
                        onValueChange = { newValue ->
                            assigneeSearchText = newValue
                            assigneeExpanded = true

                            if (selectedAssignee?.name != newValue) {
                                selectedAssignee = null
                            }
                        },
                        label = { Text("Assignee") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    DropdownMenu(
                        expanded = assigneeExpanded && (filteredAssignees.isNotEmpty() || showUnassignedOption),
                        onDismissRequest = { assigneeExpanded = false },
                        properties = PopupProperties(focusable = false),
                        modifier = Modifier.fillMaxWidth(0.8f)
                    ) {
                        if (showUnassignedOption) {
                            DropdownMenuItem(
                                text = { Text("Unassigned") },
                                onClick = {
                                    selectedAssignee = null
                                    assigneeSearchText = ""
                                    assigneeExpanded = false
                                }
                            )
                        }

                        filteredAssignees.forEach { assignee ->
                            DropdownMenuItem(
                                text = { Text(assignee.name) },
                                onClick = {
                                    selectedAssignee = assignee
                                    assigneeSearchText = assignee.name
                                    assigneeExpanded = false
                                }
                            )
                        }
                    }
                }

                // --- TOOL AUTOCOMPLETE ---
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = toolSearchText,
                        onValueChange = { newValue ->
                            toolSearchText = newValue
                            toolExpanded = true

                            if (selectedTool?.name != newValue) {
                                selectedTool = null
                            }
                        },
                        label = { Text("Tool Required") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    DropdownMenu(
                        expanded = toolExpanded && (filteredTools.isNotEmpty() || showNoToolOption),
                        onDismissRequest = { toolExpanded = false },
                        properties = PopupProperties(focusable = false),
                        modifier = Modifier.fillMaxWidth(0.8f)
                    ) {
                        if (showNoToolOption) {
                            DropdownMenuItem(
                                text = { Text("None") },
                                onClick = {
                                    selectedTool = null
                                    toolSearchText = ""
                                    toolExpanded = false
                                }
                            )
                        }

                        filteredTools.forEach { tool ->
                            DropdownMenuItem(
                                text = { Text(tool.name) },
                                onClick = {
                                    selectedTool = tool
                                    toolSearchText = tool.name
                                    toolExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    // Auto-resolve assignee if user typed exact name without tapping dropdown
                    val finalAssignee = selectedAssignee ?: assignees.find {
                        it.name.equals(assigneeSearchText.trim(), ignoreCase = true)
                    }

                    // Auto-resolve tool if user typed exact name without tapping dropdown
                    val finalTool = selectedTool ?: tools.find {
                        it.name.equals(toolSearchText.trim(), ignoreCase = true)
                    }

                    val newItem = ScheduleItem(
                        id = existingItem?.id ?: 0L,
                        date = selectedDate,
                        address = address,
                        assigneeId = finalAssignee?.id,
                        toolId = finalTool?.id
                    )
                    onSave(newItem)
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}