package com.example.schedulemanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.schedulemanager.data.Assignee
import com.example.schedulemanager.viewmodel.ScheduleViewModel

fun sanitizePhoneNumber(raw: String): String {
    val digits = raw.filter { it.isDigit() }
    if (digits.isEmpty()) return ""

    return when {
        digits.startsWith("601") -> digits
        digits.startsWith("01") -> "60" + digits.substring(1)
        digits.startsWith("1") -> "60$digits"
        else -> digits
    }
}

fun isValidPhoneNumber(sanitizedPhone: String): Boolean {
    return sanitizedPhone.length in 10..15
}

@Composable
fun AssigneesTabContent(
    viewModel: ScheduleViewModel,
    modifier: Modifier = Modifier
) {
    val assignees by viewModel.assignees.collectAsState()

    var newName by remember { mutableStateOf("") }
    var newPhone by remember { mutableStateOf("") }
    var phoneError by remember { mutableStateOf<String?>(null) }

    var duplicateWarningName by remember { mutableStateOf<String?>(null) }
    var pendingAddAction by remember { mutableStateOf<Pair<String, String>?>(null) }
    var assigneeToEdit by remember { mutableStateOf<Assignee?>(null) }
    var assigneeToDelete by remember { mutableStateOf<Assignee?>(null) }

    fun trySubmitNewAssignee() {
        val trimmedName = newName.trim()
        val sanitizedPhone = sanitizePhoneNumber(newPhone)

        if (!isValidPhoneNumber(sanitizedPhone)) {
            phoneError = "Phone number must be 10-15 digits"
            return
        }
        phoneError = null

        val isDuplicate = assignees.any { it.name.equals(trimmedName, ignoreCase = true) }
        if (isDuplicate) {
            duplicateWarningName = trimmedName
            pendingAddAction = Pair(trimmedName, sanitizedPhone)
        } else {
            viewModel.addAssignee(trimmedName, sanitizedPhone)
            newName = ""
            newPhone = ""
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = "Add New Assignee", style = MaterialTheme.typography.titleSmall)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Name") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = newPhone,
                        onValueChange = {
                            newPhone = it
                            phoneError = null
                        },
                        label = { Text("Phone Number") },
                        singleLine = true,
                        isError = phoneError != null,
                        modifier = Modifier.weight(1f)
                    )
                }

                if (phoneError != null) {
                    Text(
                        text = phoneError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Button(
                    onClick = { trySubmitNewAssignee() },
                    enabled = newName.isNotBlank() && newPhone.isNotBlank(),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Add Assignee")
                }
            }
        }

        HorizontalDivider()

        if (assignees.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No assignees saved in directory.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(
                    items = assignees,
                    key = { it.id }
                ) { assignee ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(text = assignee.name, style = MaterialTheme.typography.titleMedium)
                                }

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Phone,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "+${assignee.phoneNumber}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Row {
                                IconButton(onClick = { assigneeToEdit = assignee }) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Assignee",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }

                                IconButton(onClick = { assigneeToDelete = assignee }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete Assignee",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    duplicateWarningName?.let { name ->
        AlertDialog(
            onDismissRequest = { duplicateWarningName = null },
            title = { Text("Duplicate Assignee Name") },
            text = { Text("An assignee named '$name' already exists. Do you still want to add this contact?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        pendingAddAction?.let { (n, p) ->
                            viewModel.addAssignee(n, p)
                            newName = ""
                            newPhone = ""
                        }
                        duplicateWarningName = null
                        pendingAddAction = null
                    }
                ) {
                    Text("Add Anyway")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        duplicateWarningName = null
                        pendingAddAction = null
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    assigneeToEdit?.let { assignee ->
        var editName by remember { mutableStateOf(assignee.name) }
        var editPhone by remember { mutableStateOf(assignee.phoneNumber) }
        var editPhoneError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { assigneeToEdit = null },
            title = { Text("Edit Assignee") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editPhone,
                        onValueChange = {
                            editPhone = it
                            editPhoneError = null
                        },
                        label = { Text("Phone Number") },
                        singleLine = true,
                        isError = editPhoneError != null,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (editPhoneError != null) {
                        Text(
                            text = editPhoneError!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val sanitized = sanitizePhoneNumber(editPhone)
                        if (!isValidPhoneNumber(sanitized)) {
                            editPhoneError = "Phone number must be 10-15 digits"
                        } else {
                            viewModel.updateAssignee(
                                assignee.copy(
                                    name = editName.trim(),
                                    phoneNumber = sanitized
                                )
                            )
                            assigneeToEdit = null
                        }
                    },
                    enabled = editName.isNotBlank() && editPhone.isNotBlank()
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { assigneeToEdit = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    assigneeToDelete?.let { assignee ->
        AlertDialog(
            onDismissRequest = { assigneeToDelete = null },
            title = { Text("Delete Assignee") },
            text = { Text("Are you sure you want to delete '${assignee.name}'?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteAssignee(assignee.id)
                        assigneeToDelete = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { assigneeToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}