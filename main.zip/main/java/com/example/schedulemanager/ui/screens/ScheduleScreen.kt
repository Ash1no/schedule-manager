package com.example.schedulemanager.ui.screens

import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.schedulemanager.data.Assignee
import com.example.schedulemanager.data.ScheduleItem
import com.example.schedulemanager.viewmodel.ScheduleViewModel
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleScreen(
    viewModel: ScheduleViewModel,
    modifier: Modifier = Modifier
) {
    // --- CORRECTED VIEWMODEL STATE COLLECTIONS ---
    val scheduleItems by viewModel.displayedScheduleItems.collectAsState()
    val allSchedules by viewModel.allSchedules.collectAsState(initial = emptyList<ScheduleItem>())
    val messageTemplate by viewModel.savedTemplate.collectAsState() // Corrected: maps to savedTemplate
    val assignees by viewModel.assignees.collectAsState()
    val tools by viewModel.tools.collectAsState()
    val selectedDateStr by viewModel.selectedDate.collectAsState()
    val isEditMode by viewModel.isEditMode.collectAsState()

    var showDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<ScheduleItem?>(null) }

    // Parse string date to LocalDate safely
    val selectedDate = remember(selectedDateStr) {
        runCatching { LocalDate.parse(selectedDateStr) }.getOrDefault(LocalDate.now())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Schedule Manager", fontWeight = FontWeight.Bold) },
                actions = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(
                            text = if (isEditMode) "Edit Mode" else "View Mode",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isEditMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        FilterChip(
                            selected = isEditMode,
                            onClick = { viewModel.toggleEditMode() },
                            label = {
                                Icon(
                                    imageVector = if (isEditMode) Icons.Default.Edit else Icons.Default.Lock,
                                    contentDescription = "Toggle Edit Mode",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingItem = null
                    showDialog = true
                }
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Schedule")
            }
        },
        modifier = modifier
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // --- 1. 7-DAY HORIZONTAL WEEK STRIP ---
            WeekHeaderStrip(
                selectedDate = selectedDate,
                allSchedules = if (allSchedules.isNotEmpty()) allSchedules else scheduleItems,
                onDateSelected = { date ->
                    viewModel.setSelectedDate(date.format(DateTimeFormatter.ISO_LOCAL_DATE))
                }
            )

            HorizontalDivider()

            // --- 2. SCHEDULE LIST ---
            if (scheduleItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No schedules for this day.\nTap + to add one.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) {
                    items(scheduleItems, key = { it.id }) { item ->
                        val assignee = assignees.find { it.id == item.assigneeId }
                        val tool = tools.find { it.id == item.toolId }

                        ScheduleCard(
                            item = item,
                            assignee = assignee,
                            toolName = tool?.name ?: "None",
                            messageTemplate = messageTemplate,
                            isEditMode = isEditMode,
                            onEdit = {
                                editingItem = item
                                showDialog = true
                            },
                            onDelete = { viewModel.deleteScheduleItem(item) }
                        )
                    }
                }
            }
        }
    }

    // --- 3. ADD / EDIT DIALOG ---
    if (showDialog) {
        AddEditScheduleDialog(
            selectedDate = selectedDateStr,
            existingItem = editingItem,
            assignees = assignees,
            tools = tools,
            onDismiss = { showDialog = false },
            onSave = { newItem ->
                viewModel.addScheduleItem(newItem)
                showDialog = false
            }
        )
    }
}

// ============================================================================
// COMPONENT: 7-Day Horizontal Week Selector
// ============================================================================
@Composable
fun WeekHeaderStrip(
    selectedDate: LocalDate,
    allSchedules: List<ScheduleItem>,
    onDateSelected: (LocalDate) -> Unit
) {
    val context = LocalContext.current

    val monday = remember(selectedDate) {
        selectedDate.with(DayOfWeek.MONDAY)
    }
    val sunday = remember(monday) {
        monday.plusDays(6)
    }

    val rangeFormatter = DateTimeFormatter.ofPattern("MMM dd")
    val yearFormatter = DateTimeFormatter.ofPattern("yyyy")
    val headerText = "${monday.format(rangeFormatter)} - ${sunday.format(rangeFormatter)}, ${sunday.format(yearFormatter)}"

    val datePickerDialog = remember(selectedDate) {
        val calendar = Calendar.getInstance().apply {
            set(selectedDate.year, selectedDate.monthValue - 1, selectedDate.dayOfMonth)
        }
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selected = LocalDate.of(year, month + 1, dayOfMonth)
                onDateSelected(selected)
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(vertical = 12.dp, horizontal = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { onDateSelected(monday.minusWeeks(1)) }) {
                Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = "Previous Week")
            }

            Text(
                text = headerText,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { datePickerDialog.show() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )

            IconButton(onClick = { onDateSelected(monday.plusWeeks(1)) }) {
                Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Next Week")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            for (i in 0..6) {
                val dayDate = monday.plusDays(i.toLong())
                val isSelected = dayDate == selectedDate
                val dayName = dayDate.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).uppercase()
                val dayNum = dayDate.dayOfMonth.toString()

                val eventCount = allSchedules.count { it.date == dayDate.format(DateTimeFormatter.ISO_LOCAL_DATE) }

                DayPill(
                    dayName = dayName,
                    dayNum = dayNum,
                    isSelected = isSelected,
                    eventCount = eventCount,
                    onClick = { onDateSelected(dayDate) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun DayPill(
    dayName: String,
    dayNum: String,
    isSelected: Boolean,
    eventCount: Int = 0,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .padding(horizontal = 2.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(backgroundColor)
            .clickable { onClick() }
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = dayName,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = contentColor
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = dayNum,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = contentColor
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Dots: White on active pill, Black on unselected pills
        val maxDots = minOf(eventCount, 9)
        val topRowDots = minOf(maxDots, 5)
        val bottomRowDots = maxOf(0, maxDots - 5)
        val dotColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else Color.Black

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
            modifier = Modifier.height(10.dp)
        ) {
            if (topRowDots > 0) {
                Row(horizontalArrangement = Arrangement.spacedBy(1.5.dp)) {
                    repeat(topRowDots) {
                        Box(
                            modifier = Modifier
                                .size(3.dp)
                                .background(color = dotColor, shape = CircleShape)
                        )
                    }
                }
            }
            if (bottomRowDots > 0) {
                Row(horizontalArrangement = Arrangement.spacedBy(1.5.dp)) {
                    repeat(bottomRowDots) {
                        Box(
                            modifier = Modifier
                                .size(3.dp)
                                .background(color = dotColor, shape = CircleShape)
                        )
                    }
                }
            }
        }
    }
}

// ============================================================================
// COMPONENT: Schedule Card with Saved Template WhatsApp Integration
// ============================================================================
@Composable
fun ScheduleCard(
    item: ScheduleItem,
    assignee: Assignee?,
    toolName: String,
    messageTemplate: String,
    isEditMode: Boolean,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val assigneeName = assignee?.name ?: "Unassigned"
    val phoneNumber = assignee?.phoneNumber ?: ""

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = item.address,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )

                if (isEditMode) {
                    Row {
                        IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                } else {
                    IconButton(
                        onClick = {
                            // Uses the saved template string from ViewModel, with fallback defaults
                            val rawTemplate = messageTemplate.ifBlank {
                                "Hi {assignee}, here is your schedule:\n\n📅 Date: {date}\n📍 Address: {address}\n🛠 Tool: {tool}"
                            }

                            val formattedMessage = rawTemplate
                                .replace("{assignee}", assigneeName)
                                .replace("{name}", assigneeName)
                                .replace("{date}", item.date)
                                .replace("{address}", item.address)
                                .replace("{location}", item.address)
                                .replace("{tool}", toolName)

                            val cleanPhone = phoneNumber.filter { it.isDigit() }

                            val url = if (cleanPhone.isNotEmpty()) {
                                "https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(formattedMessage)}"
                            } else {
                                "https://api.whatsapp.com/send?text=${Uri.encode(formattedMessage)}"
                            }

                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            try {
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                val fallbackIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, formattedMessage)
                                }
                                context.startActivity(Intent.createChooser(fallbackIntent, "Share via"))
                            }
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share via WhatsApp",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SuggestionChip(
                    onClick = { },
                    label = { Text(assigneeName) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                )

                SuggestionChip(
                    onClick = { },
                    label = { Text(toolName) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                )
            }
        }
    }
}