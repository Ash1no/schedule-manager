package com.example.schedulemanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.schedulemanager.viewmodel.ScheduleViewModel

@Composable
fun TemplatesTabContent(
    viewModel: ScheduleViewModel,
    modifier: Modifier = Modifier
) {
    val savedTemplate by produceState<String>("") {
        viewModel.savedTemplate.collect { value = it }
    }
    val pendingTabSwitch by produceState<Int?>(null) {
        viewModel.pendingTabSwitch.collect { value = it }
    }

    var templateText by remember(savedTemplate) { mutableStateOf(savedTemplate) }
    var showPlaceholderDialog by remember { mutableStateOf(false) }

    val placeholders = listOf("{address}", "{time}", "{date}", "{assignee}")
    val hasUnsavedChanges = templateText != savedTemplate

    LaunchedEffect(hasUnsavedChanges) {
        viewModel.setHasUnsavedChanges(hasUnsavedChanges)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = templateText,
            onValueChange = { templateText = it },
            label = { Text("Template Message") },
            placeholder = { Text("e.g. Schedule at {address} on {time} for {assignee}") },
            minLines = 7,
            maxLines = 7,
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(onClick = { showPlaceholderDialog = true }) {
                Text("+ Add Placeholder")
            }

            Button(
                onClick = { viewModel.saveTemplate(templateText) },
                enabled = hasUnsavedChanges
            ) {
                Text("Save Template")
            }
        }
    }

    if (showPlaceholderDialog) {
        AlertDialog(
            onDismissRequest = { showPlaceholderDialog = false },
            title = { Text("Insert Placeholder") },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    placeholders.forEach { placeholder ->
                        TextButton(
                            onClick = {
                                templateText = if (templateText.isEmpty()) {
                                    placeholder
                                } else {
                                    "$templateText $placeholder"
                                }
                                showPlaceholderDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(placeholder, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showPlaceholderDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    pendingTabSwitch?.let { targetTab ->
        AlertDialog(
            onDismissRequest = { viewModel.cancelTabSwitch() },
            title = { Text("Unsaved Changes") },
            text = { Text("You have unsaved edits in your template. What would you like to do before switching tabs?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.saveTemplate(templateText)
                        viewModel.confirmTabSwitch(targetTab)
                    }
                ) {
                    Text("Save & Switch")
                }
            },
            dismissButton = {
                Row {
                    TextButton(
                        onClick = {
                            templateText = savedTemplate
                            viewModel.confirmTabSwitch(targetTab)
                        }
                    ) {
                        Text("Discard", color = MaterialTheme.colorScheme.error)
                    }
                    TextButton(onClick = { viewModel.cancelTabSwitch() }) {
                        Text("Cancel")
                    }
                }
            }
        )
    }
}