package com.example.schedulemanager.viewmodel

import android.content.SharedPreferences
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.schedulemanager.data.Assignee
import com.example.schedulemanager.data.AssigneeDao
import com.example.schedulemanager.data.ScheduleItem
import com.example.schedulemanager.data.ScheduleItemDao
import com.example.schedulemanager.data.Tool
import com.example.schedulemanager.data.ToolDao
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ScheduleViewModel(
    private val scheduleItemDao: ScheduleItemDao? = null,
    private val assigneeDao: AssigneeDao? = null,
    private val toolDao: ToolDao? = null,
    private val sharedPreferences: SharedPreferences
) : ViewModel() {

    companion object {
        private const val KEY_LAST_SELECTED_DATE = "key_last_selected_date"
        private const val DEFAULT_DATE = "2026-08-08"
        private const val KEY_SAVED_TEMPLATE = "key_saved_template"
    }

    // ==========================================
    // 1. TAB NAVIGATION STATE
    // (0: Schedule, 1: Assignees, 2: Tools)
    // ==========================================
    private val _selectedTabIndex = MutableStateFlow(0)
    val selectedTabIndex: StateFlow<Int> = _selectedTabIndex.asStateFlow()

    fun onTabSelected(index: Int) {
        _selectedTabIndex.value = index
    }

    // ==========================================
    // 2. SCHEDULE STATE & ACTIONS
    // ==========================================

    // Read previously saved date from SharedPreferences or fallback to default date
    private val savedDate: String = sharedPreferences.getString(KEY_LAST_SELECTED_DATE, DEFAULT_DATE) ?: DEFAULT_DATE

    private val _selectedDate = MutableStateFlow(savedDate)
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _isEditMode = MutableStateFlow(false)
    val isEditMode: StateFlow<Boolean> = _isEditMode.asStateFlow()

    // In-memory fallback schedule list
    private val _scheduleItems = MutableStateFlow<List<ScheduleItem>>(
        listOf(
            ScheduleItem(
                id = 1L,
                date = "2026-08-08",
                address = "123 Tech Park, Cyberjaya",
                assigneeId = 1L,
                toolId = 1L
            ),
            ScheduleItem(
                id = 2L,
                date = "2026-08-08",
                address = "456 Innovation Way, JB",
                assigneeId = 2L,
                toolId = null
            ),
            ScheduleItem(
                id = 3L,
                date = "2026-08-08",
                address = "789 Main HQ",
                assigneeId = null,
                toolId = 2L
            )
        )
    )

    // Reactive displayed schedule list (Uses Room flow if DAO present, else in-memory flow)
    @OptIn(ExperimentalCoroutinesApi::class)
    val displayedScheduleItems: StateFlow<List<ScheduleItem>> = if (scheduleItemDao != null) {
        _selectedDate.flatMapLatest { date ->
            scheduleItemDao.getScheduleForDate(date)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    } else {
        combine(_scheduleItems, _selectedDate) { items, date ->
            items.filter { it.date == date }.sortedBy { it.id }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    // --- Flow exposing ALL schedules for WeekHeaderStrip dot indicators ---
    val allSchedules: StateFlow<List<ScheduleItem>> = if (scheduleItemDao != null) {
        scheduleItemDao.getAllScheduleItems().stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    } else {
        _scheduleItems.asStateFlow()
    }

    fun toggleEditMode() {
        _isEditMode.value = !_isEditMode.value
    }

    /**
     * Updates selected date and saves it to SharedPreferences for persistence across restarts
     */
    fun setSelectedDate(date: String) {
        _selectedDate.value = date
        sharedPreferences.edit()
            .putString(KEY_LAST_SELECTED_DATE, date)
            .apply()
    }

    fun addScheduleItem(item: ScheduleItem) {
        if (scheduleItemDao != null) {
            viewModelScope.launch {
                scheduleItemDao.insertScheduleItem(item)
            }
        } else {
            val nextId = if (item.id == 0L) {
                (_scheduleItems.value.maxOfOrNull { it.id } ?: 0L) + 1L
            } else {
                item.id
            }
            val itemToSave = item.copy(id = nextId)

            _scheduleItems.value = _scheduleItems.value.filter { it.id != itemToSave.id } + itemToSave
        }
    }

    fun deleteScheduleItem(item: ScheduleItem) {
        if (scheduleItemDao != null) {
            viewModelScope.launch {
                scheduleItemDao.deleteScheduleItem(item)
            }
        } else {
            _scheduleItems.value = _scheduleItems.value.filter { it.id != item.id }
        }
    }

    // ==========================================
    // 3. ASSIGNEE STATE & ACTIONS
    // ==========================================
    private val _assignees = MutableStateFlow<List<Assignee>>(
        listOf(
            Assignee(id = 1L, name = "Alex", phoneNumber = "60123456789"),
            Assignee(id = 2L, name = "Jordan", phoneNumber = "60129876543"),
            Assignee(id = 3L, name = "Taylor", phoneNumber = "601111223344")
        )
    )

    val assignees: StateFlow<List<Assignee>> = if (assigneeDao != null) {
        assigneeDao.getAllAssignees().stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    } else {
        _assignees.asStateFlow()
    }

    fun addAssignee(name: String, phoneNumber: String = "") {
        if (assigneeDao != null) {
            viewModelScope.launch {
                val newAssignee = Assignee(name = name, phoneNumber = phoneNumber)
                assigneeDao.insertAssignee(newAssignee)
            }
        } else {
            val newId = (_assignees.value.maxOfOrNull { it.id } ?: 0L) + 1L
            _assignees.value = _assignees.value + Assignee(id = newId, name = name, phoneNumber = phoneNumber)
        }
    }

    fun updateAssignee(updatedAssignee: Assignee) {
        if (assigneeDao != null) {
            viewModelScope.launch {
                assigneeDao.updateAssignee(updatedAssignee)
            }
        } else {
            _assignees.value = _assignees.value.map { assignee ->
                if (assignee.id == updatedAssignee.id) updatedAssignee else assignee
            }
        }
    }

    fun deleteAssignee(assigneeId: Long) {
        if (assigneeDao != null) {
            viewModelScope.launch {
                val assigneeToDelete = assignees.value.find { it.id == assigneeId }
                if (assigneeToDelete != null) {
                    assigneeDao.deleteAssignee(assigneeToDelete)
                }
            }
        } else {
            _assignees.value = _assignees.value.filter { it.id != assigneeId }

            _scheduleItems.value = _scheduleItems.value.map { item ->
                if (item.assigneeId == assigneeId) item.copy(assigneeId = null) else item
            }
        }
    }

    // ==========================================
    // 4. TOOL STATE & ACTIONS
    // ==========================================
    private val _tools = MutableStateFlow<List<Tool>>(
        listOf(
            Tool(id = 1L, name = "Drill Kit", description = "Cordless power drill with bits"),
            Tool(id = 2L, name = "Ladder", description = "6ft aluminum step ladder"),
            Tool(id = 3L, name = "Multimeter", description = "Digital voltage tester")
        )
    )

    val tools: StateFlow<List<Tool>> = if (toolDao != null) {
        toolDao.getAllTools().stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    } else {
        _tools.asStateFlow()
    }

    fun addTool(name: String, description: String = "") {
        if (toolDao != null) {
            viewModelScope.launch {
                val newTool = Tool(name = name, description = description)
                toolDao.insertTool(newTool)
            }
        } else {
            val newId = (_tools.value.maxOfOrNull { it.id } ?: 0L) + 1L
            _tools.value = _tools.value + Tool(id = newId, name = name, description = description)
        }
    }

    fun updateTool(updatedTool: Tool) {
        if (toolDao != null) {
            viewModelScope.launch {
                toolDao.updateTool(updatedTool)
            }
        } else {
            _tools.value = _tools.value.map { tool ->
                if (tool.id == updatedTool.id) updatedTool else tool
            }
        }
    }

    fun deleteTool(toolId: Long) {
        if (toolDao != null) {
            viewModelScope.launch {
                val toolToDelete = tools.value.find { it.id == toolId }
                if (toolToDelete != null) {
                    toolDao.deleteTool(toolToDelete)
                }
            }
        } else {
            _tools.value = _tools.value.filter { it.id != toolId }

            _scheduleItems.value = _scheduleItems.value.map { item ->
                if (item.toolId == toolId) item.copy(toolId = null) else item
            }
        }
    }

    // ==========================================
    // 5. TEMPLATE STATE & ACTIONS
    // ==========================================
    private val _templates = MutableStateFlow<List<String>>(
        listOf("Standard Morning Shift", "Weekend Routine")
    )
    val templates: StateFlow<List<String>> = _templates.asStateFlow()

    // --- Template State & Flows ---
    private val initialTemplate: String = sharedPreferences.getString(KEY_SAVED_TEMPLATE, "") ?: ""
    private val _savedTemplate = MutableStateFlow(initialTemplate)
    val savedTemplate: StateFlow<String> = _savedTemplate.asStateFlow()

    private val _pendingTabSwitch = MutableStateFlow<Int?>(null)
    val pendingTabSwitch: StateFlow<Int?> = _pendingTabSwitch.asStateFlow()

    private val _hasUnsavedChanges = MutableStateFlow(false)
    val hasUnsavedChanges: StateFlow<Boolean> = _hasUnsavedChanges.asStateFlow()

    fun saveTemplate(newTemplate: String) {
        _savedTemplate.value = newTemplate

        // Save new template string to SharedPreferences
        sharedPreferences.edit()
            .putString(KEY_SAVED_TEMPLATE, newTemplate)
            .apply()

        _hasUnsavedChanges.value = false
    }

    fun setHasUnsavedChanges(hasChanges: Boolean) {
        _hasUnsavedChanges.value = hasChanges
    }

    fun confirmTabSwitch(targetTab: Int) {
        _pendingTabSwitch.value = null
        onTabSelected(targetTab)
    }

    fun cancelTabSwitch() {
        _pendingTabSwitch.value = null
    }
}