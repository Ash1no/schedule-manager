package com.example.schedulemanager.viewmodel

import android.content.SharedPreferences
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.schedulemanager.data.AssigneeDao
import com.example.schedulemanager.data.ScheduleItemDao
import com.example.schedulemanager.data.ToolDao

class ScheduleViewModelFactory(
    private val scheduleItemDao: ScheduleItemDao,
    private val assigneeDao: AssigneeDao,
    private val toolDao: ToolDao,
    private val sharedPreferences: SharedPreferences
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ScheduleViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ScheduleViewModel(
                scheduleItemDao = scheduleItemDao,
                assigneeDao = assigneeDao,
                toolDao = toolDao,
                sharedPreferences = sharedPreferences
            ) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}